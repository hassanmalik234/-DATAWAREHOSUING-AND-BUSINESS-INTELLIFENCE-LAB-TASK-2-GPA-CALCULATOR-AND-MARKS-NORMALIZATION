from flask import Flask, render_template, request, jsonify
from gpa_logic import calculate_gpa

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/calculate', methods=['POST'])
def calculate():
    data = request.get_json()
    subjects = data.get('subjects', [])
    gpa = calculate_gpa(subjects)
    return jsonify({'gpa': gpa})

if __name__ == '__main__':
    app.run(debug=True)
