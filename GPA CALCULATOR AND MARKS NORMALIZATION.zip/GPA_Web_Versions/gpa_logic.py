def get_grade_point(marks):
    if marks >= 90:
        return 4.0
    elif marks >= 80:
        return 3.5
    elif marks >= 70:
        return 3.0
    elif marks >= 60:
        return 2.5
    elif marks >= 50:
        return 2.0
    else:
        return 0.0

def calculate_gpa(subjects):
    total_quality_points = 0
    total_credits = 0

    for subject in subjects:
        marks = subject["marks"]
        credits = subject["credits"]

        grade_point = get_grade_point(marks)
        quality_points = grade_point * credits

        total_quality_points += quality_points
        total_credits += credits

    if total_credits == 0:
        return 0

    gpa = total_quality_points / total_credits
    return round(gpa, 2)
