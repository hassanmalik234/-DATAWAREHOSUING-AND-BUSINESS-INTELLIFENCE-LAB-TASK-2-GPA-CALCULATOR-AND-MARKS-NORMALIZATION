import streamlit as st
import pandas as pd
from gpa_logic import get_grade_point, calculate_gpa

st.set_page_config(page_title="GPA Calculator", page_icon="🎓")

st.title("🎓 GPA Calculator")

if 'subjects' not in st.session_state:
    st.session_state.subjects = []

with st.form("add_subject_form", clear_on_submit=True):
    col1, col2 = st.columns(2)
    with col1:
        marks = st.number_input("Marks (0-100)", min_value=0.0, max_value=100.0, step=0.1)
    with col2:
        credits = st.number_input("Credits (e.g., 3.0)", min_value=0.5, step=0.5)
    
    submitted = st.form_submit_button("Add Subject")
    
    if submitted:
        subject = {"marks": marks, "credits": credits}
        st.session_state.subjects.append(subject)
        st.success("Subject added!")

if st.session_state.subjects:
    st.subheader("Added Subjects")
    
    # Process data for display
    display_data = []
    for sub in st.session_state.subjects:
        gp = get_grade_point(sub['marks'])
        qp = gp * sub['credits']
        display_data.append({
            "Marks": sub['marks'],
            "Credits": sub['credits'],
            "Grade Point": gp,
            "Quality Points": qp
        })
    
    df = pd.DataFrame(display_data)
    st.dataframe(df, use_container_width=True)

    if st.button("Calculate GPA"):
        gpa = calculate_gpa(st.session_state.subjects)
        st.markdown(f"### Your GPA is: **{gpa}**")
        
        if gpa >= 3.5:
            st.success("Excellent work! Keep it up!")
        elif gpa >= 2.5:
            st.warning("Good job, but there's room for improvement.")
        else:
            st.error("You might need to study harder.")

    if st.button("Reset Calculator"):
        st.session_state.subjects = []
        st.rerun()

else:
    st.info("Add subjects to calculate your GPA.")
