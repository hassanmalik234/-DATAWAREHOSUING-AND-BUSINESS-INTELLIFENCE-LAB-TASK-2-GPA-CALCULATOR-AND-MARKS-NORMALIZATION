# GPA Calculator Web Versions

This folder contains two web versions of the GPA Calculator: one using Streamlit and one using Flask.

## Prerequisites

You need Python installed. It is recommended to create a virtual environment or just install the required packages:

```bash
pip install -r requirements.txt
```

## Running the Streamlit App

1. Open a terminal in this folder.
2. Run the following command:
   ```bash
   streamlit run app_streamlit.py
   ```
3. The app will open in your browser (usually at http://localhost:8501).

## Running the Flask App

1. Open a terminal in this folder.
2. Run the following command:
   ```bash
   python app_flask.py
   ```
3. Open your browser and go to http://127.0.0.1:5000.
